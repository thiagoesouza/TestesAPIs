package com.example.bookapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
